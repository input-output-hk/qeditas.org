(* Copyright (c) 2016 The Qeditas developers *)
(* Distributed under the MIT software license, see the accompanying
   file COPYING or http://www.opensource.org/licenses/mit-license.php. *)

let clientdescr = "Qeditas (alpha)"
let clientversion = "0.0.1"
let useragent = clientdescr ^ " " ^ clientversion
let protocolversion = 0l
